let aboutButtonElement=document.getElementById("aboutButton");
let timeTovisitButtonElement=document.getElementById("timeToVisitButton");
let attractionsButtonElement=document.getElementById("attractionsButton");

let aboutTabElement=document.getElementById("aboutTab");
let timeTovisitTabElement=document.getElementById("timeToVisitTab");
let attractionsTabElement=document.getElementById("attractionsTab");

timeTovisitTabElement.classList.add("d-none");
attractionsTabElement.classList.add("d-none");

function onClickAboutTab(){
   
    aboutTabElement.classList.remove("d-none");
    timeTovisitTabElement.classList.remove("d-none");
    attractionsTabElement.classList.add("d-none");

    aboutButtonElement.classList.add("selected-button");
    timeTovisitButtonElement.classList.remove("selected-button");
    attractionsButtonElement.classList.remove("selected-button");
}
function onClickTimeToVisitTab(){
    aboutTabElement.classList.add("d-none");
    timeTovisitTabElement.classList.remove("d-none");
    attractionsTabElement.classList.remove("d-none");

    aboutButtonElement.classList.remove("selected-button");
    timeTovisitButtonElement.claletssList.add("selected-button");
    attractionsButtonElement.classList.remove("selected-button");
}
function onClickAttractionsTab(){
    aboutTabElement.classList.remove("d-none");
    timeTovisitTabElement.classList.add("d-none");
    attractionsTabElement.classList.remove("d-none");

    aboutButtonElement.classList.remove("selected-button");
    timeTovisitButtonElement.classList.remove("selected-button");
    attractionsButtonElement.classList.add("selected-button");
}
